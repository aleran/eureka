DISCLAIMER

If you wish to customize PrestaShop for your
needs please write us for soporte@payulatam.com for more information.

@author PayU Latam <sac@payulatam.com.com>
@copyright 2016 PayU Latam
@license http://choosealicense.com/licenses/mit/
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

Release Notes for Payu Latam Payments Plugin for PrestaShop 1.6


## [v2.1.2] - (2016-05-12)
### Changed
- Updated our test environment URL to https://sandbox.gateway.payulatam.com/ppp-web-gateway/.
- Updated the payment button with our new corporate image. 



