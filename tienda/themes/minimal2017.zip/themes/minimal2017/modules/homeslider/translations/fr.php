<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{homeslider}prestashop>homeslider_693b83f5eca43e2bb1675287c37ce9e2'] = 'Diaporama (image slider) pour votre page d\'accueil';
$_MODULE['<{homeslider}prestashop>homeslider_c17aed434289cedd02618451e12c8da6'] = 'Ajouter un carrousel d\'images à votre page d\'accueil';
$_MODULE['<{homeslider}prestashop>homeslider_3f80dc2cdd06939d4f5514362067cd86'] = 'Valeur non valables';
$_MODULE['<{homeslider}prestashop>homeslider_a6abafe564d3940cc36ee43e2f09400b'] = 'Diapositive non valable';
$_MODULE['<{homeslider}prestashop>homeslider_e0ce30bfbf90d2306ecf72f06a83133f'] = 'État non valable.';
$_MODULE['<{homeslider}prestashop>homeslider_9f79795e050649dc6b8bd0cdc874cbdc'] = 'Position non valable pour la diapositive.';
$_MODULE['<{homeslider}prestashop>homeslider_5c8bedc4c0c9f42d9b0f14340bbe53da'] = 'ID invalide pour la diapositive';
$_MODULE['<{homeslider}prestashop>homeslider_14f09fd0804a8f1cd0eb757125fc9c28'] = 'Titre trop long';
$_MODULE['<{homeslider}prestashop>homeslider_dc89634d1d28cd4e055531e62047156b'] = 'La légende est trop longue.';
$_MODULE['<{homeslider}prestashop>homeslider_4477f672766f6f255f760649af8bd92a'] = 'URL trop longue';
$_MODULE['<{homeslider}prestashop>homeslider_62239300ba982b06ab0f1aa7100ad297'] = 'Description trop longue';
$_MODULE['<{homeslider}prestashop>homeslider_980f56796b8bf9d607283de9815fe217'] = 'Format d\'URL incorrect';
$_MODULE['<{homeslider}prestashop>homeslider_73133ce32267e8c7a854d15258eb17e0'] = 'Nom de fichier non valable.';
$_MODULE['<{homeslider}prestashop>homeslider_349097dadf7e6b01dd2af601d54fd59a'] = 'Titre absent';
$_MODULE['<{homeslider}prestashop>homeslider_a9af2809b02444b9470f97dc66ba57a2'] = 'Pas de légende configurée.';
$_MODULE['<{homeslider}prestashop>homeslider_0f059227d0a750ce652337d911879671'] = 'URL absente';
$_MODULE['<{homeslider}prestashop>homeslider_8cf45ba354f4725ec8a0d31164910895'] = 'Image absente';
$_MODULE['<{homeslider}prestashop>homeslider_7f82c65d548588c8d5412463c182e450'] = 'La configuration n\'a pas pu être mise à jour';
$_MODULE['<{homeslider}prestashop>homeslider_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configuration mise à jour';
$_MODULE['<{homeslider}prestashop>homeslider_7cc92687130ea12abb80556681538001'] = 'Une erreur est survenue durant l\'envoi de l\'image';
$_MODULE['<{homeslider}prestashop>homeslider_cdf841e01e10cae6355f72e6838808eb'] = 'La diapositive n\'a pas pu être ajoutée';
$_MODULE['<{homeslider}prestashop>homeslider_eb28485b92fbf9201918698245ec6430'] = 'La diapositive n\'a pas pu être mise à jour';
$_MODULE['<{homeslider}prestashop>homeslider_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{homeslider}prestashop>homeslider_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{homeslider}prestashop>homeslider_ced7338587c502f76917b5a693f848c5'] = 'Paramètres de la diapositive';
$_MODULE['<{homeslider}prestashop>homeslider_792744786ed30c5623dd1cf0c16f4ffe'] = 'Sélectionner un fichier';
$_MODULE['<{homeslider}prestashop>homeslider_61c1727eb4c54b859e250c2a76bb40c0'] = 'Titre de la diapositive';
$_MODULE['<{homeslider}prestashop>homeslider_e64df1d7c22b9638f084ce8a4aff3ff3'] = 'URL cible';
$_MODULE['<{homeslider}prestashop>homeslider_272ba7d164aa836995be6319a698be84'] = 'Légende';
$_MODULE['<{homeslider}prestashop>homeslider_b5a7adde1af5c87d7fd797b6245c2a39'] = 'Description';
$_MODULE['<{homeslider}prestashop>homeslider_93cba07454f06a4a960172bbd6e2a435'] = 'Oui';
$_MODULE['<{homeslider}prestashop>homeslider_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
$_MODULE['<{homeslider}prestashop>homeslider_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{homeslider}prestashop>homeslider_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{homeslider}prestashop>homeslider_1738daa45f573390d5745fd33ec03fa1'] = 'Largeur maximale de l\'image';
$_MODULE['<{homeslider}prestashop>homeslider_44877c6aa8e93fa5a91c9361211464fb'] = 'Vitesse';
$_MODULE['<{homeslider}prestashop>homeslider_11cd394e1bd88abe611fd331887f0c74'] = 'La durée de transition entre deux diapositives.';
$_MODULE['<{homeslider}prestashop>homeslider_105b296a83f9c105355403f3332af50f'] = 'Pause';
$_MODULE['<{homeslider}prestashop>homeslider_44f0ca4d7ea17bb667e8d5e31311d959'] = 'Le temps de pause entre deux diapositives.';
$_MODULE['<{homeslider}prestashop>homeslider_1e6a508c037fc42ef6155eeadbb80331'] = 'Lecture automatique';
$_MODULE['<{homeslider}prestashop>homeslider_5a3489cc067f89b268b6958bffb98ebf'] = 'Étant donné que plusieurs langues sont activées sur votre boutique, pensez à mettre en ligne une version de votre image par langue.';
$_MODULE['<{homeslider}prestashop>homeslider_c8a1ed10db4201b3ae06ea0aa912028d'] = 'Vous ne pouvez gérer les diapositives pour un groupe de boutiques ou toutes les boutiques à la fois. Sélectionnez directement la boutique que vous souhaitez modifier';
$_MODULE['<{homeslider}prestashop>homeslider_71063fd397d237e563089c22dd8b69e8'] = 'Les modifications seront appliquées à toutes les boutiques et tous les groupes de boutiques.';
$_MODULE['<{homeslider}prestashop>form_92fbf0e5d97b8afd7e73126b52bdc4bb'] = 'Choisissez un fichier';
$_MODULE['<{homeslider}prestashop>list_c82324ebbcea34f55627a897b37190e3'] = 'Liste des diapositives';
$_MODULE['<{homeslider}prestashop>list_7dce122004969d56ae2e0245cb754d35'] = 'Modifier';
$_MODULE['<{homeslider}prestashop>list_f2a6c498fb90ee345d997f888fce3b18'] = 'Supprimer';


return $_MODULE;
