<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockleorelatedproducts}leoconv>blockleorelatedproducts_876b62c6cff1d65b3465df83123be02f'] = 'Leo Produits Associés Bloquer';
$_MODULE['<{blockleorelatedproducts}leoconv>blockleorelatedproducts_1666b78ee26e3234f03b1b0a6fe7fd49'] = 'Afficher les produits dans la même catégorie ou Rapporté par Tag .... dans le carrousel.';
$_MODULE['<{blockleorelatedproducts}leoconv>blockleorelatedproducts_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour';
$_MODULE['<{blockleorelatedproducts}leoconv>blockleorelatedproducts_3c7679577cd1d0be2b98faf898cfc56d'] = 'Date d\'insertion';
$_MODULE['<{blockleorelatedproducts}leoconv>blockleorelatedproducts_235e70e4e7c0a3d61ccb6f60518ebd24'] = 'Date d\'insertion DESC';
$_MODULE['<{blockleorelatedproducts}leoconv>blockleorelatedproducts_49ee3087348e8d44e1feda1917443987'] = 'Nom';
$_MODULE['<{blockleorelatedproducts}leoconv>blockleorelatedproducts_1b7bb88b3317fe166424fa9e7535e1a9'] = 'Nom DESC';
$_MODULE['<{blockleorelatedproducts}leoconv>blockleorelatedproducts_694e8d1f2ee056f98ee488bdc4982d73'] = 'Quantité';
$_MODULE['<{blockleorelatedproducts}leoconv>blockleorelatedproducts_003085dd2a352e197d8efea06dfa75b8'] = 'Quantité DESC';
$_MODULE['<{blockleorelatedproducts}leoconv>blockleorelatedproducts_3601146c4e948c32b6424d2c0a7f0118'] = 'Prix';
$_MODULE['<{blockleorelatedproducts}leoconv>blockleorelatedproducts_32da8a9347c34947b76a0a33d59edf4c'] = 'Prix ​​DESC';
$_MODULE['<{blockleorelatedproducts}leoconv>blockleorelatedproducts_f4f70727dc34561dfde1a3c529b6205c'] = 'Réglages';
$_MODULE['<{blockleorelatedproducts}leoconv>blockleorelatedproducts_b53787b5af6c89a0de9f1cf54fba9f21'] = 'Le nombre maximum de produits dans chaque page Carousel (par défaut: 3).';
$_MODULE['<{blockleorelatedproducts}leoconv>blockleorelatedproducts_52a9719fc56cce0f0ea20673203c3ed7'] = 'Les produits de colonnes maximum dans chaque page Carousel (par défaut: 3).';
$_MODULE['<{blockleorelatedproducts}leoconv>blockleorelatedproducts_fc60123368f78620dcd75cde90aeec36'] = 'Le nombre maximum de produits dans chaque Carousel (par défaut: 6).';
$_MODULE['<{blockleorelatedproducts}leoconv>blockleorelatedproducts_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockleorelatedproducts}leoconv>blockleorelatedproducts_4aae87211f77aada2c87907121576cfe'] = 'autres produits dans la même catégorie:';
$_MODULE['<{blockleorelatedproducts}leoconv>params_93cba07454f06a4a960172bbd6e2a435'] = 'Qui';
$_MODULE['<{blockleorelatedproducts}leoconv>params_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
$_MODULE['<{blockleorelatedproducts}leoconv>products_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nouveau';
$_MODULE['<{blockleorelatedproducts}leoconv>products_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Plus';
$_MODULE['<{blockleorelatedproducts}leoconv>products_4351cfebe4b61d8aa5efa1d020710005'] = 'Voir';
$_MODULE['<{blockleorelatedproducts}leoconv>products_2d0f6b8300be19cf35e89e66f0677f95'] = 'Ajouter au panier';
$_MODULE['<{blockleorelatedproducts}leoconv>blockleorelatedproducts_38070661d5ad384d9c7d21895dc4e784'] = 'Produits associés';
