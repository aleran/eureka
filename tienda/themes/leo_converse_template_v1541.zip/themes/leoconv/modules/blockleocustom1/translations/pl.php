<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockleocustom1}leoconv>blockleocustom1_c4724f9dc773495d9304e299411921cd'] = 'Wyświetlanie niestandardowego HOME1 HTML';
$_MODULE['<{blockleocustom1}leoconv>blockleocustom1_0c7ffff1998a86d31d97d979ba5d8ae5'] = 'Wyświetlanie niestandardowego kodu HTML, Wsparcie Wszystkie haki';
$_MODULE['<{blockleocustom1}leoconv>blockleocustom1_cc3787ca78f445f481069a4c047f7e7a'] = 'Wybierz język:';
$_MODULE['<{blockleocustom1}leoconv>blockleocustom1_21efafa62ac903fa766465b46cd0c4b1'] = 'Ustawienia aktualizacji sukces';
$_MODULE['<{blockleocustom1}leoconv>blockleocustom1_22f93742ec42ed6aae9f55a400b05a40'] = 'Moduł wprowadzony wysokość nie pozwolono, sorry';
$_MODULE['<{blockleocustom1}leoconv>blockleocustom1_4468859e6385e01b66ef40cf01127722'] = 'Własny HTML Konfiguracja modułu';
$_MODULE['<{blockleocustom1}leoconv>blockleocustom1_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Nie';
$_MODULE['<{blockleocustom1}leoconv>blockleocustom1_93cba07454f06a4a960172bbd6e2a435'] = 'Tak';
$_MODULE['<{blockleocustom1}leoconv>blockleocustom1_06933067aafd48425d67bcb01bba5cb6'] = 'Aktualizacja';
$_MODULE['<{blockleocustom1}leoconv>blockleocustom1_f15c1cae7882448b3fb0404682e17e61'] = 'Zawartość';
$_MODULE['<{blockleocustom1}leoconv>blockleocustom1_cd56aaa6883976c9794319e1fe62137a'] = 'Tytuł modułu';
$_MODULE['<{blockleocustom1}leoconv>blockleocustom1_7ae86b38c443080cbdd64fb22ab1116f'] = 'Pokaż tytuł:';
$_MODULE['<{blockleocustom1}leoconv>blockleocustom1_577aba35cd8eec7a912f8105a251fc55'] = 'Prefix Class';
