<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocklanguages}leoconv>blocklanguages_d5988791c07fedc0e2fc77683b4e61f6'] = 'Blok językowy';
$_MODULE['<{blocklanguages}leoconv>blocklanguages_5b2b53f769604bcbee6f67882c73fb94'] = 'Dodaje blok wyboru języka';
$_MODULE['<{blocklanguages}leoconv>blocklanguages_4994a8ffeba4ac3140beb89e8d41f174'] = 'Językowy';
