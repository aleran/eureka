<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockadvertising}leoconv>blockadvertising_fd4c71c948857cce596a69fbaea7426b'] = 'Bloc publicité';
$_MODULE['<{blockadvertising}leoconv>blockadvertising_91cd1ee56ea5324ff51578684a393a81'] = 'Ajoute un bloc affichant une publicité';
$_MODULE['<{blockadvertising}leoconv>blockadvertising_070e16b4f77b90e802f789b5be583cfa'] = 'Erreur de déplacement du fichier mis en ligne';
$_MODULE['<{blockadvertising}leoconv>blockadvertising_6e7be6d836003f069c00cd217660913b'] = 'Configuration du bloc de publicité';
$_MODULE['<{blockadvertising}leoconv>blockadvertising_a21056e22c4d62b400b5dd96dafe22a3'] = 'Vous ne pouvez pas supprimer l\'image par défaut (Mais vous pouvez la modifier ci-dessous)';
$_MODULE['<{blockadvertising}leoconv>blockadvertising_83b5a65e518c21ed0a5f2b383dd9b617'] = 'supprimer l\'image';
$_MODULE['<{blockadvertising}leoconv>blockadvertising_9dd7104e68d1b5f994264b9387c9d271'] = 'pas d\'image';
$_MODULE['<{blockadvertising}leoconv>blockadvertising_8c38cf08a0d0a01bd44c682479432350'] = 'Changer l\'image';
$_MODULE['<{blockadvertising}leoconv>blockadvertising_56d9dfa26d7848a3fbcd2ae3091d38d9'] = 'L\'image sera affichée en 155x163.';
$_MODULE['<{blockadvertising}leoconv>blockadvertising_9ce38727cff004a058021a6c7351a74a'] = 'Lien de l\'image';
$_MODULE['<{blockadvertising}leoconv>blockadvertising_b78a3223503896721cca1303f776159b'] = 'Titre';
$_MODULE['<{blockadvertising}leoconv>blockadvertising_ad3d06d03d94223fa652babc913de686'] = 'Valider';
