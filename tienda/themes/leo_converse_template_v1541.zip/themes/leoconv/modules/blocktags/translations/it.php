<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocktags}leoconv>blocktags_f2568a62d4ac8d1d5b532556379772ba'] = 'Blocco tags';
$_MODULE['<{blocktags}leoconv>blocktags_2a87377a6bc89f0dfe2eafe3b240c19c'] = 'Aggiunge un blocco contenente una nuvola di tag';
$_MODULE['<{blocktags}leoconv>blocktags_c484b0cda62bd4dbd9c22d095e1b654c'] = 'È necessario compilare il campo \"tag visualizzati\"';
$_MODULE['<{blocktags}leoconv>blocktags_73293a024e644165e9bf48f270af63a0'] = 'Numero non valido.';
$_MODULE['<{blocktags}leoconv>blocktags_c888438d14855d7d96a2724ee9c306bd'] = 'Impostazioni aggiornate';
$_MODULE['<{blocktags}leoconv>blocktags_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{blocktags}leoconv>blocktags_a2701a006c71c9097d80ea1ddaea8fa9'] = 'Tag visualizzati';
$_MODULE['<{blocktags}leoconv>blocktags_2ae74fc125d2af584b168312cdf79dc0'] = 'Imposta il numero di tag da visualizzare in questo blocco';
$_MODULE['<{blocktags}leoconv>blocktags_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
$_MODULE['<{blocktags}leoconv>blocktags_189f63f277cd73395561651753563065'] = 'Tag';
$_MODULE['<{blocktags}leoconv>blocktags_49fa2426b7903b3d4c89e2c1874d9346'] = 'Maggiori informazioni su';
$_MODULE['<{blocktags}leoconv>blocktags_4e6307cfde762f042d0de430e82ba854'] = 'Nessun tag ancora specificato';
