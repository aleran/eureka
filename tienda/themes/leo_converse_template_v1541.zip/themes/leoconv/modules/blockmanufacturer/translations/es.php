<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockmanufacturer}leoconv>blockmanufacturer_bc3e73cfa718a3237fb1d7e1da491395'] = 'Bloque de marcas';
$_MODULE['<{blockmanufacturer}leoconv>blockmanufacturer_71087c7035e626bd33c72ae9a7f042af'] = 'Mostrar bloque de marcas';
$_MODULE['<{blockmanufacturer}leoconv>blockmanufacturer_067931ed6c365d76c9f32285a6b49839'] = 'número de elementos no válido';
$_MODULE['<{blockmanufacturer}leoconv>blockmanufacturer_5b2e13ff6fa0da895d14bd56f2cb2d2d'] = 'Por favor, active al menos uno de la lista';
$_MODULE['<{blockmanufacturer}leoconv>blockmanufacturer_c888438d14855d7d96a2724ee9c306bd'] = 'Actualización realizada con éxito';
$_MODULE['<{blockmanufacturer}leoconv>blockmanufacturer_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuración';
$_MODULE['<{blockmanufacturer}leoconv>blockmanufacturer_b4251faa73b3c8188623fdc8fe287513'] = 'Usar una lista de texto plano';
$_MODULE['<{blockmanufacturer}leoconv>blockmanufacturer_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activado';
$_MODULE['<{blockmanufacturer}leoconv>blockmanufacturer_b9f5c797ebbf55adccdd8539a65a0241'] = 'Desactivado';
$_MODULE['<{blockmanufacturer}leoconv>blockmanufacturer_b9987a246a537f4fe86f1f2e3d10dbdb'] = 'Mostrar';
$_MODULE['<{blockmanufacturer}leoconv>blockmanufacturer_aa56a2e65d8106aef3c61e4f6bf94fdb'] = 'elementos';
$_MODULE['<{blockmanufacturer}leoconv>blockmanufacturer_c6dfa38603c2ea64217d462000a09da4'] = 'Para mostrar marcas en une lista de texto plano';
$_MODULE['<{blockmanufacturer}leoconv>blockmanufacturer_ac88955a067710291274d21dec443904'] = 'Usar un cuadro combinado';
$_MODULE['<{blockmanufacturer}leoconv>blockmanufacturer_56353167778d1520bfecc70c470e6d8a'] = 'Para mostrar las marcas dentro de un cuadro combinado';
$_MODULE['<{blockmanufacturer}leoconv>blockmanufacturer_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blockmanufacturer}leoconv>blockmanufacturer_2377be3c2ad9b435ba277a73f0f1ca76'] = 'Marcas';
$_MODULE['<{blockmanufacturer}leoconv>blockmanufacturer_9d098ff02f6813055b869f6f9acd831c'] = 'Más sobre';
$_MODULE['<{blockmanufacturer}leoconv>blockmanufacturer_bf24faeb13210b5a703f3ccef792b000'] = 'Todas las marcas';
$_MODULE['<{blockmanufacturer}leoconv>blockmanufacturer_1c407c118b89fa6feaae6b0af5fc0970'] = 'Sin marcas';
