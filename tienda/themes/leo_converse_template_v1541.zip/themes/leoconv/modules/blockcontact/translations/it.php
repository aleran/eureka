<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcontact}leoconv>blockcontact_0f45a6908556b5b1d7c7d79e60fa3fa7'] = 'Blocco contatti';
$_MODULE['<{blockcontact}leoconv>blockcontact_318ed85b9852475f24127167815e85d9'] = 'Ti permette di aggiungere informazioni aggiuntive sul servizio clienti';
$_MODULE['<{blockcontact}leoconv>blockcontact_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configurazione aggiornata';
$_MODULE['<{blockcontact}leoconv>blockcontact_17870f54a180e69e60e84125f805db67'] = 'Numero di telefono:';
$_MODULE['<{blockcontact}leoconv>blockcontact_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'E-mail';
$_MODULE['<{blockcontact}leoconv>blockcontact_b17f3f4dcf653a5776792498a9b44d6a'] = 'Aggiorna le impostazioni';
$_MODULE['<{blockcontact}leoconv>blockcontact_02d4482d332e1aef3437cd61c9bcc624'] = 'Contattaci';
$_MODULE['<{blockcontact}leoconv>blockcontact_75858d311c84e7ba706b69bea5c71d36'] = 'Hot line disponibile 24/7';
$_MODULE['<{blockcontact}leoconv>blockcontact_673ae02fffb72f0fe68a66f096a01347'] = 'Telefono:';
$_MODULE['<{blockcontact}leoconv>blockcontact_736c5a7e834b7021bfa97180fc453115'] = 'Contatta la nostra Hot line';
