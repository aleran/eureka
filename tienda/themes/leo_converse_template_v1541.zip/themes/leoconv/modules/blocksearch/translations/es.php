<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksearch}leoconv>blocksearch-top_13348442cc6a27032d2b4aa28b75a5d3'] = 'Buscar';
$_MODULE['<{blocksearch}leoconv>blocksearch_e2ca130372651672ba285abd796412ed'] = 'Bloque de búsqueda rápida';
$_MODULE['<{blocksearch}leoconv>blocksearch_be305c865235f417d9b4d22fcdf9f1c5'] = 'Añada u bloque con un campo de búsqueda rápida';
$_MODULE['<{blocksearch}leoconv>blocksearch_13348442cc6a27032d2b4aa28b75a5d3'] = 'Buscar';
$_MODULE['<{blocksearch}leoconv>blocksearch_3d4999b5a4129d6c189f50d6f977b846'] = 'Introduzca el nombre del producto';
$_MODULE['<{blocksearch}leoconv>blocksearch_1fb103afe92d693ae23d0463b185a9a7'] = 'buscar';
