<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockleocustom3}leoconv>blockleocustom3_dc7db8fcb86a48ac365af28d2e440297'] = 'Afficher Accueil Bas HTML personnalisé';
$_MODULE['<{blockleocustom3}leoconv>blockleocustom3_0c7ffff1998a86d31d97d979ba5d8ae5'] = 'Afficher HTML personnalisé, soutien Tous les crochets';
$_MODULE['<{blockleocustom3}leoconv>blockleocustom3_cc3787ca78f445f481069a4c047f7e7a'] = 'Choisissez la langue:';
$_MODULE['<{blockleocustom3}leoconv>blockleocustom3_21efafa62ac903fa766465b46cd0c4b1'] = 'Paramètres mis à jour réussie';
$_MODULE['<{blockleocustom3}leoconv>blockleocustom3_22f93742ec42ed6aae9f55a400b05a40'] = 'La hauteur du module que vous avez entré n\'a pas été autorisé, désolé';
$_MODULE['<{blockleocustom3}leoconv>blockleocustom3__dc7db8fcb86a48ac365af28d2e440297'] = 'Afficher Accueil Bas HTML personnalisé';
$_MODULE['<{blockleocustom3}leoconv>blockleocustom3__0c7ffff1998a86d31d97d979ba5d8ae5'] = 'Afficher HTML personnalisé, soutien Tous les crochets';
$_MODULE['<{blockleocustom3}leoconv>blockleocustom3__cc3787ca78f445f481069a4c047f7e7a'] = 'Choisissez la langue:';
$_MODULE['<{blockleocustom3}leoconv>blockleocustom3__21efafa62ac903fa766465b46cd0c4b1'] = 'Paramètres mis à jour réussie';
$_MODULE['<{blockleocustom3}leoconv>blockleocustom3__22f93742ec42ed6aae9f55a400b05a40'] = 'La hauteur du module que vous avez entré n\'a pas été autorisé, désolé';
$_MODULE['<{blockleocustom3}leoconv>lofcustom_4468859e6385e01b66ef40cf01127722'] = 'HTML personnalisé de configuration du module';
$_MODULE['<{blockleocustom3}leoconv>lofcustom_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
$_MODULE['<{blockleocustom3}leoconv>lofcustom_93cba07454f06a4a960172bbd6e2a435'] = 'Oui';
$_MODULE['<{blockleocustom3}leoconv>lofcustom_06933067aafd48425d67bcb01bba5cb6'] = 'Mettre à jour';
$_MODULE['<{blockleocustom3}leoconv>lofcustom_f15c1cae7882448b3fb0404682e17e61'] = 'Content';
$_MODULE['<{blockleocustom3}leoconv>lofcustom_cd56aaa6883976c9794319e1fe62137a'] = 'Titre du Module';
$_MODULE['<{blockleocustom3}leoconv>lofcustom_7ae86b38c443080cbdd64fb22ab1116f'] = 'Afficher le titre:';
$_MODULE['<{blockleocustom3}leoconv>lofcustom_577aba35cd8eec7a912f8105a251fc55'] = 'préfixe de classe';
