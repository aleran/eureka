<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcategories}leoconv>blockcategories_8f0ed7c57fca428f7e3f8e64d2f00918'] = 'Bloc catégories';
$_MODULE['<{blockcategories}leoconv>blockcategories_15a6f5841d9e4d7e62bec3319b4b7036'] = 'Ajoute un bloc proposant une navigation au sein de vos catégories de produits';
$_MODULE['<{blockcategories}leoconv>blockcategories_23e0d4ecc25de9b2777fdaca3e2f3193'] = 'Profondeur maximum : nombre invalide';
$_MODULE['<{blockcategories}leoconv>blockcategories_0cf328636f0d607ac24a5c435866b94b'] = 'Dynamic HTML : choix invalide';
$_MODULE['<{blockcategories}leoconv>blockcategories_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour';
$_MODULE['<{blockcategories}leoconv>blockcategories_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{blockcategories}leoconv>blockcategories_19561e33450d1d3dfe6af08df5710dd0'] = 'Profondeur maximum';
$_MODULE['<{blockcategories}leoconv>blockcategories_ef35cd8f1058f29151991e9ca94b36fb'] = 'Détermine la profondeur maximale affichée (0 = infinie)';
$_MODULE['<{blockcategories}leoconv>blockcategories_971fd8cc345d8bd9f92e9f7d88fdf20c'] = 'Dynamique';
$_MODULE['<{blockcategories}leoconv>blockcategories_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{blockcategories}leoconv>blockcategories_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{blockcategories}leoconv>blockcategories_e16f248b047fb7d0c97dcc19b17296a3'] = 'Activer l\'arbre dynamique (animé)';
$_MODULE['<{blockcategories}leoconv>blockcategories_6b46ae48421828d9973deec5fa9aa0c3'] = 'Trier';
$_MODULE['<{blockcategories}leoconv>blockcategories_883f0bd41a4fcee55680446ce7bec0d9'] = 'par position';
$_MODULE['<{blockcategories}leoconv>blockcategories_54e4f98fb34254a6678f0795476811ed'] = 'par nom';
$_MODULE['<{blockcategories}leoconv>blockcategories_cf3fb1ff52ea1eed3347ac5401ee7f0c'] = 'croissant';
$_MODULE['<{blockcategories}leoconv>blockcategories_e3cf5ac19407b1a62c6fccaff675a53b'] = 'décroissant';
$_MODULE['<{blockcategories}leoconv>blockcategories_5f73e737cedf8f4ccf880473a7823005'] = 'Nombre de colonnes pour le pied de page';
$_MODULE['<{blockcategories}leoconv>blockcategories_d5e74c74b1457c285adc8b2c2ab03767'] = 'Détermine le nombre de colonne pour le footer';
$_MODULE['<{blockcategories}leoconv>blockcategories_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockcategories}leoconv>blockcategories_af1b98adf7f686b84cd0b443e022b7a0'] = 'Catégories';
$_MODULE['<{blockcategories}leoconv>blockcategories_footer_af1b98adf7f686b84cd0b443e022b7a0'] = 'Catégories';
