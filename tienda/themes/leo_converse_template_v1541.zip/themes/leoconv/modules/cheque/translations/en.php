<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{cheque}leoconv>payment_execution_0881a11f7af33bc1b43e437391129d66'] = 'Please confirm your order by clicking \'I confirm my order\'';
$_MODULE['<{cheque}leoconv>payment_return_e1c54fdba2544646684f41ace03b5fda'] = 'Do not forget to include your order number #%d.';
$_MODULE['<{cheque}leoconv>payment_return_4761b03b53bc2b3bd948bb7443a26f31'] = 'Do not forget to include your order reference %s.';
$_MODULE['<{cheque}leoconv>cheque_7b4cc4f79be9aae43efd53b4ae5cba4d'] = 'Payment by check';
$_MODULE['<{cheque}leoconv>payment_841728ede901f5134574c4656aba5464'] = 'Pay by check (order processing will take more time)';
