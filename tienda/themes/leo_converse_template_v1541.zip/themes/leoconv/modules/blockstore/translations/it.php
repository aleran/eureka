<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockstore}leoconv>blockstore_68e9ecb0ab69b1121fe06177868b8ade'] = 'Blocco negozi';
$_MODULE['<{blockstore}leoconv>blockstore_2d7884c3777bd04028c4a55a820880a8'] = 'Visualizza un blocco con un link per il localizzatore del negozio';
$_MODULE['<{blockstore}leoconv>blockstore_126b21ce46c39d12c24058791a236777'] = 'immagine non valida';
$_MODULE['<{blockstore}leoconv>blockstore_df7859ac16e724c9b1fba0a364503d72'] = 'un errore sul caricamento del file';
$_MODULE['<{blockstore}leoconv>blockstore_efc226b17e0532afff43be870bff0de7'] = 'Le impostazioni sono aggiornate';
$_MODULE['<{blockstore}leoconv>blockstore_151e79863510ec66281329505bf9fbde'] = 'Configurazione blocco negozio';
$_MODULE['<{blockstore}leoconv>blockstore_2dd1d28275cdb8b78ebd17f6e25aac0d'] = 'Immagine blocco';
$_MODULE['<{blockstore}leoconv>blockstore_8c38cf08a0d0a01bd44c682479432350'] = 'Cambia immagine';
$_MODULE['<{blockstore}leoconv>blockstore_3eedfc0fbc9042acf0ecfe0f325428c4'] = 'immagine verrà visualizzata come 174x115';
$_MODULE['<{blockstore}leoconv>blockstore_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
$_MODULE['<{blockstore}leoconv>blockstore_8c0caec5616160618b362bcd4427d97b'] = 'I nostri negozi';
$_MODULE['<{blockstore}leoconv>blockstore_142fe29b7422147cdac10259a0333c11'] = 'Scopri i nostri negozi';
$_MODULE['<{blockstore}leoconv>blockstore_28fe12f949fd191685071517628df9b3'] = 'Scopri il nostro negozio (s)!';
