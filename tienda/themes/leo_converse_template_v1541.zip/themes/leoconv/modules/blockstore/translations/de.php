<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockstore}leoconv>blockstore_68e9ecb0ab69b1121fe06177868b8ade'] = 'Shop-Finder';
$_MODULE['<{blockstore}leoconv>blockstore_2d7884c3777bd04028c4a55a820880a8'] = 'Zeigt ein Block mit einem Link zum Shop-Finder';
$_MODULE['<{blockstore}leoconv>blockstore_126b21ce46c39d12c24058791a236777'] = 'Bild ungültig';
$_MODULE['<{blockstore}leoconv>blockstore_df7859ac16e724c9b1fba0a364503d72'] = 'Fehler beim Hochladen der Datei';
$_MODULE['<{blockstore}leoconv>blockstore_efc226b17e0532afff43be870bff0de7'] = 'Einstellungen werden aktualisiert';
$_MODULE['<{blockstore}leoconv>blockstore_151e79863510ec66281329505bf9fbde'] = 'Konfiguration Block Shop-Finder';
$_MODULE['<{blockstore}leoconv>blockstore_2dd1d28275cdb8b78ebd17f6e25aac0d'] = 'Shop-Bild';
$_MODULE['<{blockstore}leoconv>blockstore_8c38cf08a0d0a01bd44c682479432350'] = 'Bild ändern';
$_MODULE['<{blockstore}leoconv>blockstore_3eedfc0fbc9042acf0ecfe0f325428c4'] = 'Bild wird in der Größe 174x115px angezeigt';
$_MODULE['<{blockstore}leoconv>blockstore_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{blockstore}leoconv>blockstore_8c0caec5616160618b362bcd4427d97b'] = 'Unsere Shops';
$_MODULE['<{blockstore}leoconv>blockstore_142fe29b7422147cdac10259a0333c11'] = 'Entdecken Sie unsere Shops';
$_MODULE['<{blockstore}leoconv>blockstore_28fe12f949fd191685071517628df9b3'] = 'Entdecken Sie unsere Shop (s)!';
