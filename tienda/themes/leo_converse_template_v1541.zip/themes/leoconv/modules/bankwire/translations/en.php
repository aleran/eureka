<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{bankwire}leoconv>payment_return_63fb3f7c94ee5d8027bf599885de279d'] = 'Do not forget to insert your order number #%d in the subject of your bank wire.';
$_MODULE['<{bankwire}leoconv>payment_eb1d50032721fa4c9d3518c417f91b9d'] = 'Pay by bank wire (order processing will take more time)';
