<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_36183891b6ad0395ebc28201267ff843'] = 'Leo Productos Carousel Bloquear';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_2a96ef70e47122f45b14250d76646dd5'] = 'Mostrar productos de las categorías de Carousel.';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_c888438d14855d7d96a2724ee9c306bd'] = 'Configuración actualizado';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_3c7679577cd1d0be2b98faf898cfc56d'] = 'Fecha de alta';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_235e70e4e7c0a3d61ccb6f60518ebd24'] = 'Fecha de alta DESC';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_49ee3087348e8d44e1feda1917443987'] = 'Nombre';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_1b7bb88b3317fe166424fa9e7535e1a9'] = 'Nombre DESC';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_694e8d1f2ee056f98ee488bdc4982d73'] = 'Cantidad';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_003085dd2a352e197d8efea06dfa75b8'] = 'Cantidad DESC';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_3601146c4e948c32b6424d2c0a7f0118'] = 'Precio';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_32da8a9347c34947b76a0a33d59edf4c'] = 'Precio DESC';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuración';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_0464a3a8e8a79cb31698239b8a57d207'] = 'El número máximo de productos en cada página del carrusel (por defecto: 4). ';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_8d3e4062ddab6050ddebaa0b52ea00ea'] = 'Los productos de columna máximo en cada página del carrusel (por defecto: 4).';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_4dfe84d30e86a689bee6dad89d5aba29'] = 'El número máximo de productos en cada carrusel (por defecto: 8).';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_db5bbee0cb649caceaa88f704351ac80'] = 'Últimos productos';
$_MODULE['<{blockleoprodcarousel}leoconv>params_93cba07454f06a4a960172bbd6e2a435'] = 'Sí.';
$_MODULE['<{blockleoprodcarousel}leoconv>params_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{blockleoprodcarousel}leoconv>products_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nuevo';
$_MODULE['<{blockleoprodcarousel}leoconv>products_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Más';
$_MODULE['<{blockleoprodcarousel}leoconv>products_4351cfebe4b61d8aa5efa1d020710005'] = 'Ver';
$_MODULE['<{blockleoprodcarousel}leoconv>products_2d0f6b8300be19cf35e89e66f0677f95'] = 'Añadir a cesta';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_9ff0635f5737513b1a6f559ac2bff745'] = 'Nuevos productos';
