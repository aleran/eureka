<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_36183891b6ad0395ebc28201267ff843'] = 'Leo Produkty Carousel bloku';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_2a96ef70e47122f45b14250d76646dd5'] = 'Pokaż produkty z kategorii w Karuzeli.';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_c888438d14855d7d96a2724ee9c306bd'] = 'Ustawienia aktualizacji';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_3c7679577cd1d0be2b98faf898cfc56d'] = 'Data Dodaj';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_235e70e4e7c0a3d61ccb6f60518ebd24'] = 'Data add desc';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_49ee3087348e8d44e1feda1917443987'] = 'Nazwa';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_1b7bb88b3317fe166424fa9e7535e1a9'] = 'Imię DESC';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_694e8d1f2ee056f98ee488bdc4982d73'] = 'Ilość';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_003085dd2a352e197d8efea06dfa75b8'] = 'Ilość DESC';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_3601146c4e948c32b6424d2c0a7f0118'] = 'Cena';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_32da8a9347c34947b76a0a33d59edf4c'] = 'Cena DESC';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_f4f70727dc34561dfde1a3c529b6205c'] = 'Ustawienia';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_0464a3a8e8a79cb31698239b8a57d207'] = 'Maksymalna ilość produktów w poszczególnych Karuzela strony (domyślnie: 4).';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_8d3e4062ddab6050ddebaa0b52ea00ea'] = 'Maksymalne produkty kolumn w każdym Karuzela stronie (domyślnie: 4).';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_4dfe84d30e86a689bee6dad89d5aba29'] = 'Maksymalna ilość produktów w poszczególnych Karuzela (domyślnie: 8).';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_c9cc8cce247e49bae79f15173ce97354'] = 'Oszczędzać';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_db5bbee0cb649caceaa88f704351ac80'] = 'Ultimi Prodotti';
$_MODULE['<{blockleoprodcarousel}leoconv>params_93cba07454f06a4a960172bbd6e2a435'] = 'Tak';
$_MODULE['<{blockleoprodcarousel}leoconv>params_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Nie';
$_MODULE['<{blockleoprodcarousel}leoconv>products_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nowa';
$_MODULE['<{blockleoprodcarousel}leoconv>products_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Więcej';
$_MODULE['<{blockleoprodcarousel}leoconv>products_4351cfebe4b61d8aa5efa1d020710005'] = 'Wyświetl';
$_MODULE['<{blockleoprodcarousel}leoconv>products_2d0f6b8300be19cf35e89e66f0677f95'] = 'Dodaj do koszyka';
$_MODULE['<{blockleoprodcarousel}leoconv>blockleoprodcarousel_9ff0635f5737513b1a6f559ac2bff745'] = 'Nowe produkty';
