<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockuserinfo}leoconv>blockuserinfo_a2e9cd952cda8ba167e62b25a496c6c1'] = 'Block Benutzerinfo';
$_MODULE['<{blockuserinfo}leoconv>blockuserinfo_970a31aa19d205f92ccfd1913ca04dc0'] = 'Fügt einen Block hinzu, der Informationen über den Kunden anzeigt';
$_MODULE['<{blockuserinfo}leoconv>blockuserinfo_0c3bf3014aafb90201805e45b5e62881'] = 'Zum Warenkorb';
$_MODULE['<{blockuserinfo}leoconv>blockuserinfo_a85eba4c6c699122b2bb1387ea4813ad'] = 'Warenkorb:';
$_MODULE['<{blockuserinfo}leoconv>blockuserinfo_deb10517653c255364175796ace3553f'] = 'Produkt';
$_MODULE['<{blockuserinfo}leoconv>blockuserinfo_068f80c7519d0528fb08e82137a72131'] = 'Produkte';
$_MODULE['<{blockuserinfo}leoconv>blockuserinfo_9e65b51e82f2a9b9f72ebe3e083582bb'] = '(Leer)';
$_MODULE['<{blockuserinfo}leoconv>blockuserinfo_2cbfb6731610056e1d0aaacde07096c1'] = 'Ihren Kundenbereich anzeigen';
$_MODULE['<{blockuserinfo}leoconv>blockuserinfo_a0623b78a5f2cfe415d9dbbd4428ea40'] = 'Ihr Konto';
$_MODULE['<{blockuserinfo}leoconv>blockuserinfo_83218ac34c1834c26781fe4bde918ee4'] = 'Willkommen';
$_MODULE['<{blockuserinfo}leoconv>blockuserinfo_4b877ba8588b19f1b278510bf2b57ebb'] = 'Abmelden';
$_MODULE['<{blockuserinfo}leoconv>blockuserinfo_4394c8d8e63c470de62ced3ae85de5ae'] = 'Abmelden';
$_MODULE['<{blockuserinfo}leoconv>blockuserinfo_b145abfd6b2f88971d725cbd94a5879f'] = 'Login für Ihren Kundenbereich';
$_MODULE['<{blockuserinfo}leoconv>blockuserinfo_99dea78007133396a7b8ed70578ac6ae'] = 'Anmelden';
$_MODULE['<{blockuserinfo}leoconv>blockuserinfo_b75443a19207ed3a3552edda86536857'] = 'Einkaufswagen';
