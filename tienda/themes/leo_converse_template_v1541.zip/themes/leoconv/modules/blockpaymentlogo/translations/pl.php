<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockpaymentlogo}leoconv>blockpaymentlogo_ea2d4e3948f9543e5939efd1663ddef5'] = 'Blok logo płatności';
$_MODULE['<{blockpaymentlogo}leoconv>blockpaymentlogo_d272c8b17089521db4660c7852f8839c'] = 'Dodaj blok prezentujący loga wszystkich płatności.';
$_MODULE['<{blockpaymentlogo}leoconv>blockpaymentlogo_fb0c64625321a2f2e5e8800a7ddbd759'] = 'Logo płatności';
$_MODULE['<{blockpaymentlogo}leoconv>blockpaymentlogo_efc226b17e0532afff43be870bff0de7'] = 'Ustawienia są zaktualizowane';
$_MODULE['<{blockpaymentlogo}leoconv>blockpaymentlogo_5c5e5371da7ab2c28d1af066a1a1cc0d'] = 'Strona CMS nie jest dostępna';
$_MODULE['<{blockpaymentlogo}leoconv>blockpaymentlogo_f1206f9fadc5ce41694f69129aecac26'] = 'Konfiguruj';
$_MODULE['<{blockpaymentlogo}leoconv>blockpaymentlogo_4b3c34d991275b9fdb0facfcea561be9'] = 'Strona CMS do linku';
$_MODULE['<{blockpaymentlogo}leoconv>blockpaymentlogo_01bb71b3e70e9e5057c9678a903d47ac'] = 'Wybier stronę';
$_MODULE['<{blockpaymentlogo}leoconv>blockpaymentlogo_d4dccb8ca2dac4e53c01bd9954755332'] = 'Zapisz ustawienia';
