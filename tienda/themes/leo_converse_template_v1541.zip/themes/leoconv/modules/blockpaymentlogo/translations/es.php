<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockpaymentlogo}leoconv>blockpaymentlogo_ea2d4e3948f9543e5939efd1663ddef5'] = 'Bloque de logos de pago';
$_MODULE['<{blockpaymentlogo}leoconv>blockpaymentlogo_d272c8b17089521db4660c7852f8839c'] = 'Añadir un bloque para mostrar todos los logos de modos de pago';
$_MODULE['<{blockpaymentlogo}leoconv>blockpaymentlogo_fb0c64625321a2f2e5e8800a7ddbd759'] = 'Logos de pago';
$_MODULE['<{blockpaymentlogo}leoconv>blockpaymentlogo_efc226b17e0532afff43be870bff0de7'] = 'Parámetros actualizados';
$_MODULE['<{blockpaymentlogo}leoconv>blockpaymentlogo_5c5e5371da7ab2c28d1af066a1a1cc0d'] = 'Página CMS no disponible';
$_MODULE['<{blockpaymentlogo}leoconv>blockpaymentlogo_f1206f9fadc5ce41694f69129aecac26'] = 'Configure';
$_MODULE['<{blockpaymentlogo}leoconv>blockpaymentlogo_4b3c34d991275b9fdb0facfcea561be9'] = 'Página CMS para enlaces';
$_MODULE['<{blockpaymentlogo}leoconv>blockpaymentlogo_01bb71b3e70e9e5057c9678a903d47ac'] = 'Seleccionar una página';
$_MODULE['<{blockpaymentlogo}leoconv>blockpaymentlogo_d4dccb8ca2dac4e53c01bd9954755332'] = 'Guardar los parámetros';
