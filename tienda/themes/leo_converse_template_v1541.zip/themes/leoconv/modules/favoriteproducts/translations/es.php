<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{favoriteproducts}leoconv>favoriteproducts_c249aeb21294d5e97598462b550e73eb'] = 'Productos favoritos';
$_MODULE['<{favoriteproducts}leoconv>favoriteproducts_018770f4456d82ec755cd9d0180e4cce'] = 'Mostrar una página con los productos favoritos de los clientes';
$_MODULE['<{favoriteproducts}leoconv>favoriteproducts-account_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Mi cuenta';
$_MODULE['<{favoriteproducts}leoconv>favoriteproducts-account_e5090b68524b1bbfd7983bfa9500b7c9'] = 'Mis productos favoritos';
$_MODULE['<{favoriteproducts}leoconv>favoriteproducts-account_44fd621c6504b8a5346946650682a842'] = 'No hay producto favorito.';
$_MODULE['<{favoriteproducts}leoconv>favoriteproducts-account_6f16227b3e634872e87b0501948310b6'] = 'Volver a su cuenta';
$_MODULE['<{favoriteproducts}leoconv>favoriteproducts-extra_8128d66be9351da562f9b01f591e00cd'] = 'Agregar este producto a mis favoritos';
$_MODULE['<{favoriteproducts}leoconv>favoriteproducts-extra_b895a379bd5ea51680ead24ee13a1bb7'] = 'Sacar de mis favoritos';
$_MODULE['<{favoriteproducts}leoconv>my-account_e5090b68524b1bbfd7983bfa9500b7c9'] = 'Mis productos favoritos';
