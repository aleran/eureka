<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksupplier}leoconv>blocksupplier_9ae42413e3cb9596efe3857f75bad3df'] = 'Blocco fornitori';
$_MODULE['<{blocksupplier}leoconv>blocksupplier_7518289633b3d69dfa42cfe8d64940a5'] = 'Aggiunge un blocco di visualizzazione di fornitori di prodotto.';
$_MODULE['<{blocksupplier}leoconv>blocksupplier_cf64d2d0bc5de5ce3d309d0e899d36fb'] = 'Non valido il numero di elementi';
$_MODULE['<{blocksupplier}leoconv>blocksupplier_5b2e13ff6fa0da895d14bd56f2cb2d2d'] = 'Si prega di attivare almeno un elenco di sistema.';
$_MODULE['<{blocksupplier}leoconv>blocksupplier_c888438d14855d7d96a2724ee9c306bd'] = 'Impostazioni aggiornate';
$_MODULE['<{blocksupplier}leoconv>blocksupplier_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{blocksupplier}leoconv>blocksupplier_b4251faa73b3c8188623fdc8fe287513'] = 'Utilizzare un elenco di solo testo.';
$_MODULE['<{blocksupplier}leoconv>blocksupplier_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Abilitato';
$_MODULE['<{blocksupplier}leoconv>blocksupplier_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabile';
$_MODULE['<{blocksupplier}leoconv>blocksupplier_b9987a246a537f4fe86f1f2e3d10dbdb'] = 'Mostrare';
$_MODULE['<{blocksupplier}leoconv>blocksupplier_aa56a2e65d8106aef3c61e4f6bf94fdb'] = 'Elementi';
$_MODULE['<{blocksupplier}leoconv>blocksupplier_abafe33995bb3ad9f51fbbe2dd309bf8'] = 'Visualizzare i fornitori come un elenco di solo testo';
$_MODULE['<{blocksupplier}leoconv>blocksupplier_ac88955a067710291274d21dec443904'] = 'Utilizzare l\'elenco a discesa.';
$_MODULE['<{blocksupplier}leoconv>blocksupplier_d02aed94c0fd8800800f9ca6920acc4b'] = 'Visualizzare i fornitori come un elenco a discesa.';
$_MODULE['<{blocksupplier}leoconv>blocksupplier_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
$_MODULE['<{blocksupplier}leoconv>blocksupplier_1814d65a76028fdfbadab64a5a8076df'] = 'Fornitori';
$_MODULE['<{blocksupplier}leoconv>blocksupplier_49fa2426b7903b3d4c89e2c1874d9346'] = 'Più su';
$_MODULE['<{blocksupplier}leoconv>blocksupplier_ecf253735ac0cba84a9d2eeff1f1b87c'] = 'Tutti i fornitori';
$_MODULE['<{blocksupplier}leoconv>blocksupplier_496689fbd342f80d30f1f266d060415a'] = 'Nessun fornitore';
