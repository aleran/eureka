<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksharefb}leoconv>blocksharefb_cbe5bf6cf027e9f9e6cc0e8d725ebfa6'] = 'Bloque Compartir en Facebook';
$_MODULE['<{blocksharefb}leoconv>blocksharefb_f96f72b5ba39796e728cc55ddd1672cb'] = 'Agrega un bloque para mostrar un enlace \"Compartir en Facebook\" en las páginas de productos.';
$_MODULE['<{blocksharefb}leoconv>blocksharefb_353005a70db1e1dac3aadedec7596bd7'] = 'Compartir en Facebook';
