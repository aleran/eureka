<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksharefb}leoconv>blocksharefb_cbe5bf6cf027e9f9e6cc0e8d725ebfa6'] = 'Blocco condividi su FaceBook';
$_MODULE['<{blocksharefb}leoconv>blocksharefb_f96f72b5ba39796e728cc55ddd1672cb'] = 'Aggiungi un blocco per visualizzare un link “Condividi su FaceBook” nella pagina prodotto.';
$_MODULE['<{blocksharefb}leoconv>blocksharefb_353005a70db1e1dac3aadedec7596bd7'] = 'Condividi su Facebook';
