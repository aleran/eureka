<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksharefb}leoconv>blocksharefb_cbe5bf6cf027e9f9e6cc0e8d725ebfa6'] = 'Blok Udostępnij na Facebook';
$_MODULE['<{blocksharefb}leoconv>blocksharefb_f96f72b5ba39796e728cc55ddd1672cb'] = 'Dodaje blok wyświetlający link \"Udostępnij na Facebook\" na stronie produktu';
$_MODULE['<{blocksharefb}leoconv>blocksharefb_353005a70db1e1dac3aadedec7596bd7'] = 'Udostępnij na Facebook';
