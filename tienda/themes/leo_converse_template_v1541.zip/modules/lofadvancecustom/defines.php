<?php
/**
 * $ModDesc
 * 
 * @version		$Id: file.php $Revision
 * @package		modules
 * @subpackage	$Subpackage.
 * @copyright	Copyright (C) December 2010 LandOfCoder.com <@emai:landofcoder@gmail.com>.All rights reserved.
 * @license		GNU General Public License version 2
 */
define('LOF_MODULE_NAME_CUSTOM', 'lofadvancecustom');
define('LOF_MODULE_ADVANCE_CUSTOM_LIMIT_BLOCK', 5);

global $lofPosition;
$lofPosition = array(1,2,3,4);